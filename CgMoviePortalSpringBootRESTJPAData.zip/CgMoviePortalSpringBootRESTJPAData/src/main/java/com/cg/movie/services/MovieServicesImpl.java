package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.daoservices.SongsDAO;
import com.cg.movie.exceptions.MovieNotFoundException;

@Component("movieServices")
public class MovieServicesImpl implements MovieServices {

	@Autowired
	private MovieDAO movieDAO;
	@Autowired
	private SongsDAO songsDAO;
	
	@Override
	public Movie acceptMovieDetails(Movie movie) {
	    movie = movieDAO.save(movie);
	    Songs songs = new Songs();
	    songs.setMovie(movie);
		songsDAO.save(songs);
		return movie;
	}

	@Override
	public Movie getMovieDetails(String movieName) throws MovieNotFoundException {
		Movie movie = movieDAO.findById(movieName).orElseThrow(()->new MovieNotFoundException("Sorry Movie Name Not Found!"));
		return movie;
	}

	@Override
	public List<Movie> getAllMovieDetails() {
		return movieDAO.findAll();
	}

	@Override
	public boolean removeMovieDetails(String movieName) throws MovieNotFoundException {
	    Movie movie = movieDAO.findById(movieName).orElseThrow(()->new MovieNotFoundException("Sorry Movie Name Not Found!"));
	    movieDAO.delete(movie);
		return true;
	}

	@Override
	public List<Songs> getMovieAllSongsList(String movieName) throws MovieNotFoundException {
		Movie movie = getMovieDetails(movieName);
		return songsDAO.findAll();
	}

	@Override
	public Songs acceptSongDetails(String movieName, Songs songs) throws MovieNotFoundException {
		Movie movie = getMovieDetails(movieName);
		songs.setMovie(movie);
		songsDAO.save(songs);
		return songs;
	}

}
